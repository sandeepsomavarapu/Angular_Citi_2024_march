import { Directive, ElementRef, Renderer2, HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[appDemoDirective]'
})
export class DemoDirective {

  constructor(private el: ElementRef, private renderer: Renderer2) {
   this.changeColor('red');

  }

  @HostBinding('style.border') border: string | undefined;
  @HostListener('click') onclick(){
    this.changeColor('blue');
    this.border= '10px solid black';
  }

  
   changeColor(color: string) {
    this.renderer.setStyle(this.el.nativeElement, 'color', color);
  }

}
