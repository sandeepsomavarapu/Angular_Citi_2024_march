import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Component } from '@angular/core';

@Component({
  selector: 'child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component {

@Output()
  notify:EventEmitter<string>=new EventEmitter<string>();


  sendData()
  {
    this.notify.emit("this message is from child");
  }
}
