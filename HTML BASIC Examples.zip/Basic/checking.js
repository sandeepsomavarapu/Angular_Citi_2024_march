var a = 10;
console.log(a);
